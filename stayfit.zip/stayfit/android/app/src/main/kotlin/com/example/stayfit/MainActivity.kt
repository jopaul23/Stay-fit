package com.example.stayfit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
