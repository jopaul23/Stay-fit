import 'package:stayfit/models/message_model.dart';

class MessageDb {
  static List<String> botMessages = [
    "Hii Jopaul Joy,\nGood morning",
  ];
}
